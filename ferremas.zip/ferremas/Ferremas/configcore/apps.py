from django.apps import AppConfig


class ConfigcoreConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'configcore'
