from django.shortcuts import render
import Transaction

def index(request):
    tx = Transaction(WebpayOptions(IntegrationCommerceCodes.WEBPAY_PLUS, IntegrationApiKeys.WEBPAY, IntegrationType.TEST))
    
    if request.method=="POST":
        resp = tx.create(buy_order, session_id, amount, return_url)
        return render(request,'success.html',resp)
    return render(request,'index.html',)

# views.py

from .utils import get_dollar_value

def index(request):
    dollar_value = get_dollar_value()
    url_to_link = "https://v6.exchangerate-api.com/v6/00bb997b796d15d8ea7ee901/latest/USD"  # Aquí puedes poner el enlace que desees
    return render(request, 'index.html', {'dollar_value': dollar_value, 'url_to_link': url_to_link})


    
